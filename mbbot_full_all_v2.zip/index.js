/**
 * MB Bot FULL ALL v2
 * - Multi API song song
 * - Admin panel web
 * - Sửa bot token / chat id / admin password / api / tốc độ check ngay trên panel
 * - Thêm / sửa / xoá / bật tắt API
 * - Dashboard
 * - Queue chống spam Telegram
 * - Chống trùng giao dịch
 * - Chạy Node.js 18+
 */

const fs = require("fs");
const path = require("path");
const http = require("http");
const crypto = require("crypto");
const { URL } = require("url");

const ROOT = __dirname;
const CONFIG_FILE = path.join(ROOT, "config.json");
const STATE_FILE = path.join(ROOT, "seen.json");
const PORT = Number(process.env.PORT || 3000);

const DEFAULT_CONFIG = {
  botToken: "",
  chatId: "",
  adminPassword: "123456",
  checkIntervalMs: 4000,
  sendDelayMs: 1200,
  telegramRetry: 5,
  telegramRetryDelayMs: 1500,
  maxSeen: 5000,
  batchMode: true,
  workerEnabled: true,
  apis: [
    {
      id: "api_1",
      name: "MB API 1",
      url: "https://thueapibank.com/historyapimbbank/529ac6b9fec7758cff3209ebd864e180",
      enabled: true
    }
  ]
};

let config = null;
let seenSet = new Set();
let seenList = [];
let firstRunPerApi = {};
let queue = Promise.resolve();
let lastCheckAt = null;
let lastSuccessAt = null;
let totalSent = 0;
let totalErrors = 0;
let workers = [];
let apiStats = {};
const sessions = new Map();

function uid(prefix = "id") {
  return `${prefix}_${crypto.randomBytes(6).toString("hex")}`;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function esc(s = "") {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function nowISO() {
  return new Date().toISOString();
}

function safeNumber(value, fallback, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  if (n < min) return min;
  if (n > max) return max;
  return n;
}

function formatMoney(x) {
  const n = Number(String(x || "0").replace(/[^\d.-]/g, ""));
  if (Number.isNaN(n)) return `${x} VND`;
  return n.toLocaleString("vi-VN") + " VND";
}

function trimText(s = "", max = 800) {
  s = String(s || "").trim();
  if (s.length <= max) return s;
  return s.slice(0, max - 3) + "...";
}

function ensureConfigShape(raw) {
  const merged = { ...DEFAULT_CONFIG, ...(raw || {}) };
  merged.botToken = String(merged.botToken || "").trim();
  merged.chatId = String(merged.chatId || "").trim();
  merged.adminPassword = String(merged.adminPassword || "123456");
  merged.checkIntervalMs = safeNumber(merged.checkIntervalMs, 4000, 1000, 3600000);
  merged.sendDelayMs = safeNumber(merged.sendDelayMs, 1200, 0, 60000);
  merged.telegramRetry = safeNumber(merged.telegramRetry, 5, 1, 20);
  merged.telegramRetryDelayMs = safeNumber(merged.telegramRetryDelayMs, 1500, 100, 60000);
  merged.maxSeen = safeNumber(merged.maxSeen, 5000, 100, 100000);
  merged.batchMode = Boolean(merged.batchMode);
  merged.workerEnabled = merged.workerEnabled !== false;

  if (!Array.isArray(merged.apis) || !merged.apis.length) {
    merged.apis = JSON.parse(JSON.stringify(DEFAULT_CONFIG.apis));
  }

  merged.apis = merged.apis.map((x, i) => ({
    id: String(x?.id || uid("api")),
    name: String(x?.name || `API ${i + 1}`),
    url: String(x?.url || "").trim(),
    enabled: x?.enabled !== false,
    running: false
  })).filter(x => x.url);

  if (!merged.apis.length) {
    merged.apis = JSON.parse(JSON.stringify(DEFAULT_CONFIG.apis));
  }

  return merged;
}

function loadConfig() {
  try {
    if (!fs.existsSync(CONFIG_FILE)) {
      config = ensureConfigShape(DEFAULT_CONFIG);
      saveConfig();
      return;
    }
    const raw = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
    config = ensureConfigShape(raw);
    saveConfig();
  } catch (err) {
    console.log("[CONFIG] load error:", err.message);
    config = ensureConfigShape(DEFAULT_CONFIG);
    saveConfig();
  }
}

function saveConfig() {
  const copy = JSON.parse(JSON.stringify(config));
  for (const api of copy.apis) delete api.running;
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(copy, null, 2), "utf8");
}

function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return;
    const parsed = JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
    if (Array.isArray(parsed.refs)) {
      seenList = parsed.refs.map(String);
      seenSet = new Set(seenList);
    }
    if (parsed.firstRunPerApi && typeof parsed.firstRunPerApi === "object") {
      firstRunPerApi = parsed.firstRunPerApi;
    }
    if (parsed.apiStats && typeof parsed.apiStats === "object") {
      apiStats = parsed.apiStats;
    }
  } catch (err) {
    console.log("[STATE] load error:", err.message);
  }
}

function saveState() {
  try {
    fs.writeFileSync(
      STATE_FILE,
      JSON.stringify(
        {
          refs: seenList,
          firstRunPerApi,
          apiStats,
          updatedAt: nowISO(),
          total: seenList.length
        },
        null,
        2
      ),
      "utf8"
    );
  } catch (err) {
    console.log("[STATE] save error:", err.message);
  }
}

function maskToken(token) {
  token = String(token || "");
  if (!token) return "(chưa cấu hình)";
  if (token.length < 10) return "***";
  return token.slice(0, 8) + "..." + token.slice(-6);
}

function parseCookies(cookieHeader = "") {
  const out = {};
  cookieHeader.split(";").forEach(part => {
    const idx = part.indexOf("=");
    if (idx > -1) {
      out[part.slice(0, idx).trim()] = decodeURIComponent(part.slice(idx + 1).trim());
    }
  });
  return out;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => {
      data += chunk;
      if (data.length > 1024 * 1024) {
        req.destroy();
        reject(new Error("Body too large"));
      }
    });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

async function parseForm(req) {
  const raw = await readBody(req);
  return Object.fromEntries(new URLSearchParams(raw));
}

function isAuthed(req) {
  const sid = parseCookies(req.headers.cookie || "").sid;
  if (!sid) return false;
  const exp = sessions.get(sid);
  if (!exp) return false;
  if (Date.now() > exp) {
    sessions.delete(sid);
    return false;
  }
  return true;
}

function issueSession(res) {
  const sid = crypto.randomBytes(24).toString("hex");
  sessions.set(sid, Date.now() + 7 * 24 * 60 * 60 * 1000);
  res.setHeader("Set-Cookie", `sid=${sid}; HttpOnly; Path=/; Max-Age=604800; SameSite=Lax`);
}

function destroySession(req, res) {
  const sid = parseCookies(req.headers.cookie || "").sid;
  if (sid) sessions.delete(sid);
  res.setHeader("Set-Cookie", "sid=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax");
}

function redirect(res, location) {
  res.writeHead(302, { Location: location });
  res.end();
}

function addSeen(refNo) {
  if (!refNo || seenSet.has(refNo)) return;
  seenSet.add(refNo);
  seenList.push(refNo);
  if (seenList.length > config.maxSeen) {
    const extra = seenList.length - config.maxSeen;
    const removed = seenList.splice(0, extra);
    for (const r of removed) seenSet.delete(r);
  }
}

function hasSeen(refNo) {
  return seenSet.has(refNo);
}

function normalizeTransactions(list) {
  if (!Array.isArray(list)) return [];
  return list
    .filter(tx => tx && tx.refNo)
    .map(tx => ({
      refNo: String(tx.refNo || "").trim(),
      accountNo: tx.accountNo || "",
      creditAmount: tx.creditAmount || "0",
      debitAmount: tx.debitAmount || "0",
      description: tx.description || "",
      transactionDate: tx.transactionDate || "",
      postingDate: tx.postingDate || "",
      currency: tx.currency || "VND"
    }))
    .filter(tx => tx.refNo);
}

function buildSingleMessage(tx, apiName = "") {
  const amount =
    Number(tx.creditAmount || 0) > 0
      ? formatMoney(tx.creditAmount)
      : Number(tx.debitAmount || 0) > 0
      ? "-" + formatMoney(tx.debitAmount)
      : "0 VND";

  return [
    "💸 <b>Giao dịch mới</b>",
    apiName ? `Nguồn API : <b>${esc(apiName)}</b>` : "",
    `Tài Khoản : <code>${esc(tx.accountNo || "Không rõ")}</code>`,
    `Số Tiền : <b>${esc(amount)}</b>`,
    `Nội Dung : ${esc(trimText(tx.description || "Không có", 1200))}`,
    `Ngày Giờ : ${esc(tx.transactionDate || tx.postingDate || "Không rõ")}`,
    `Mã GD : <code>${esc(tx.refNo)}</code>`
  ].filter(Boolean).join("\n");
}

function buildBatchMessage(list, apiName = "") {
  const lines = [];
  lines.push(`💸 <b>Có ${list.length} giao dịch mới</b>`);
  if (apiName) lines.push(`Nguồn API : <b>${esc(apiName)}</b>`);
  lines.push("");
  list.forEach((tx, i) => {
    const amount =
      Number(tx.creditAmount || 0) > 0
        ? formatMoney(tx.creditAmount)
        : Number(tx.debitAmount || 0) > 0
        ? "-" + formatMoney(tx.debitAmount)
        : "0 VND";
    lines.push(`<b>${i + 1}.</b>`);
    lines.push(`Tài Khoản : <code>${esc(tx.accountNo || "Không rõ")}</code>`);
    lines.push(`Số Tiền : <b>${esc(amount)}</b>`);
    lines.push(`Nội Dung : ${esc(trimText(tx.description || "Không có", 400))}`);
    lines.push(`Ngày Giờ : ${esc(tx.transactionDate || tx.postingDate || "Không rõ")}`);
    lines.push(`Mã GD : <code>${esc(tx.refNo)}</code>`);
    lines.push("");
  });
  let msg = lines.join("\n");
  if (msg.length > 3900) msg = msg.slice(0, 3850) + "\n\n<i>... tin nhắn đã được rút gọn</i>";
  return msg;
}

async function sendTelegram(text) {
  if (!config.botToken) throw new Error("Chưa cấu hình botToken");
  if (!config.chatId) throw new Error("Chưa cấu hình chatId");
  const url = `https://api.telegram.org/bot${config.botToken}/sendMessage`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: config.chatId,
      text,
      parse_mode: "HTML",
      disable_web_page_preview: true
    })
  });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data || !data.ok) {
    const errMsg = data ? JSON.stringify(data) : `${res.status} ${res.statusText}`;
    throw new Error(`Telegram send failed: ${errMsg}`);
  }
  return data;
}

async function sendWithRetry(text) {
  let attempt = 0;
  let delay = config.telegramRetryDelayMs;
  while (attempt < config.telegramRetry) {
    try {
      attempt++;
      await sendTelegram(text);
      return true;
    } catch (err) {
      console.log(`[TG] attempt ${attempt}/${config.telegramRetry} failed: ${err.message}`);
      if (attempt >= config.telegramRetry) throw err;
      await sleep(delay);
      delay *= 2;
    }
  }
}

function enqueue(taskFn) {
  queue = queue.then(() => taskFn()).catch(err => {
    totalErrors++;
    console.log("[QUEUE] error:", err.message);
  });
  return queue;
}

async function processNotifications(apiName, newTxs) {
  if (!newTxs.length) return;
  newTxs = [...newTxs].reverse();

  if (config.batchMode && newTxs.length > 1) {
    await enqueue(async () => {
      await sendWithRetry(buildBatchMessage(newTxs, apiName));
      totalSent += newTxs.length;
      await sleep(config.sendDelayMs);
    });
    return;
  }

  for (const tx of newTxs) {
    await enqueue(async () => {
      await sendWithRetry(buildSingleMessage(tx, apiName));
      totalSent++;
      await sleep(config.sendDelayMs);
    });
  }
}

function getApiStat(apiId) {
  if (!apiStats[apiId]) {
    apiStats[apiId] = {
      success: 0,
      errors: 0,
      lastStatus: "idle",
      lastError: "",
      lastCheckAt: "",
      lastSuccessAt: "",
      lastNewTxCount: 0
    };
  }
  return apiStats[apiId];
}

async function fetchApi(api) {
  const res = await fetch(api.url, {
    method: "GET",
    headers: {
      Accept: "application/json",
      "User-Agent": "Mozilla/5.0 MB-Telegram-Bot",
      "Cache-Control": "no-cache"
    }
  });
  if (!res.ok) throw new Error(`API ${res.status} ${res.statusText}`);
  const json = await res.json();
  if (!json || json.status !== "success" || !Array.isArray(json.TranList)) {
    throw new Error("API trả về sai định dạng");
  }
  return normalizeTransactions(json.TranList);
}

async function checkApi(api, index) {
  if (!config.workerEnabled || !api.enabled || api.running) return;

  api.running = true;
  lastCheckAt = nowISO();
  const stat = getApiStat(api.id);
  stat.lastCheckAt = lastCheckAt;
  stat.lastStatus = "checking";

  try {
    const list = await fetchApi(api);
    const key = api.url;

    if (!firstRunPerApi[key]) {
      for (const tx of list) addSeen(tx.refNo);
      firstRunPerApi[key] = true;
      stat.lastStatus = "initialized";
      stat.success++;
      stat.lastNewTxCount = 0;
      stat.lastSuccessAt = nowISO();
      saveState();
      console.log(`[INIT] ${api.name}: đã ghi nhớ ${list.length} giao dịch cũ`);
      return;
    }

    const newTxs = list.filter(tx => !hasSeen(tx.refNo));
    stat.lastNewTxCount = newTxs.length;

    if (!newTxs.length) {
      lastSuccessAt = nowISO();
      stat.lastStatus = "ok";
      stat.success++;
      stat.lastSuccessAt = lastSuccessAt;
      saveState();
      return;
    }

    for (const tx of newTxs) addSeen(tx.refNo);
    saveState();
    console.log(`[CHECK] ${api.name}: ${newTxs.length} giao dịch mới`);
    await processNotifications(api.name, newTxs);
    lastSuccessAt = nowISO();
    stat.lastStatus = "ok";
    stat.success++;
    stat.lastSuccessAt = lastSuccessAt;
  } catch (err) {
    totalErrors++;
    stat.errors++;
    stat.lastStatus = "error";
    stat.lastError = err.message;
    console.log(`[API ${index + 1}] ${api.name} error: ${err.message}`);
  } finally {
    api.running = false;
  }
}

function stopWorkers() {
  for (const timer of workers) clearInterval(timer);
  workers = [];
}

function startWorkers() {
  stopWorkers();
  if (!config.workerEnabled) return;
  config.apis.forEach((api, index) => {
    const timer = setInterval(() => checkApi(api, index), config.checkIntervalMs);
    workers.push(timer);
  });
  console.log(`[BOT] workers started: ${config.apis.length}, interval=${config.checkIntervalMs}ms`);
}

async function runFirstCheckAll() {
  for (let i = 0; i < config.apis.length; i++) {
    await checkApi(config.apis[i], i);
  }
}

function htmlPage(title, body) {
  return `<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>${esc(title)}</title>
<style>
body{font-family:Arial,sans-serif;background:#0f1115;color:#eaeef5;margin:0;padding:20px}
.container{max-width:1280px;margin:0 auto}
.card{background:#171b22;border:1px solid #2c3340;border-radius:16px;padding:18px;margin-bottom:18px}
h1,h2,h3{margin:0 0 14px}
input,button{padding:12px;border-radius:10px;border:1px solid #323b4a;background:#0f1115;color:#fff}
input[type=text],input[type=password],input[type=number]{width:100%;box-sizing:border-box}
button{cursor:pointer;background:#2563eb;border:none}
button.red{background:#dc2626}
button.gray{background:#374151}
button.green{background:#059669}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}
table{width:100%;border-collapse:collapse}
td,th{padding:10px;border-bottom:1px solid #2c3340;text-align:left;vertical-align:top}
small{color:#9ca3af;word-break:break-all}
a{color:#93c5fd;text-decoration:none}
.badge{display:inline-block;padding:4px 10px;border-radius:999px;background:#1f2937}
.success{color:#86efac}
.warn{color:#fde68a}
.danger{color:#fca5a5}
.muted{color:#9ca3af}
form.inline{display:inline}
pre{white-space:pre-wrap;background:#0f1115;padding:12px;border-radius:12px;border:1px solid #2c3340}
.section-title{display:flex;justify-content:space-between;align-items:center;gap:10px}
</style>
</head>
<body><div class="container">${body}</div></body>
</html>`;
}

function loginPage(message = "") {
  return htmlPage("Login", `
    <div class="card" style="max-width:420px;margin:60px auto">
      <h1>Admin Panel</h1>
      <p class="muted">Đăng nhập để quản lý bot.</p>
      ${message ? `<p class="warn">${esc(message)}</p>` : ""}
      <form method="POST" action="/login">
        <label>Mật khẩu admin</label><br/><br/>
        <input type="password" name="password" placeholder="Nhập adminPassword"/>
        <br/><br/>
        <button type="submit">Đăng nhập</button>
      </form>
    </div>
  `);
}

function apiRowsHtml() {
  return config.apis.map((api, idx) => {
    const stat = getApiStat(api.id);
    return `
    <tr>
      <td>${idx + 1}</td>
      <td>${esc(api.name)}</td>
      <td><small>${esc(api.url)}</small></td>
      <td>${api.enabled ? '<span class="success">Bật</span>' : '<span class="warn">Tắt</span>'}</td>
      <td>
        <div>Trạng thái: <b>${esc(stat.lastStatus)}</b></div>
        <div>New tx: <b>${stat.lastNewTxCount || 0}</b></div>
        <div>Success: <b>${stat.success || 0}</b></div>
        <div>Error: <b>${stat.errors || 0}</b></div>
        <div><small>Last check: ${esc(stat.lastCheckAt || "-")}</small></div>
        <div><small>Last ok: ${esc(stat.lastSuccessAt || "-")}</small></div>
        ${stat.lastError ? `<div class="danger"><small>${esc(stat.lastError)}</small></div>` : ""}
      </td>
      <td>
        <form method="POST" action="/api/update">
          <input type="hidden" name="index" value="${idx}"/>
          <input type="text" name="name" value="${esc(api.name)}" placeholder="Tên API"/><br/><br/>
          <input type="text" name="url" value="${esc(api.url)}" placeholder="Link API"/><br/><br/>
          <button type="submit" class="green">Lưu sửa</button>
        </form>
        <br/><br/>
        <form class="inline" method="POST" action="/api/toggle">
          <input type="hidden" name="index" value="${idx}"/>
          <button type="submit" class="gray">${api.enabled ? "Tắt" : "Bật"}</button>
        </form>
        <form class="inline" method="POST" action="/api/delete" onsubmit="return confirm('Xoá API này?')">
          <input type="hidden" name="index" value="${idx}"/>
          <button type="submit" class="red">Xoá</button>
        </form>
      </td>
    </tr>`;
  }).join("");
}

function dashboardPage(msg = "") {
  return htmlPage("MB Bot Admin", `
    <div class="card">
      <div class="section-title">
        <div>
          <h1>MB Bot FULL ALL v2</h1>
          <p class="muted">Multi API + dashboard + sửa bot ngay trên panel.</p>
        </div>
        <div><a href="/logout">Đăng xuất</a></div>
      </div>
      ${msg ? `<p class="success">${esc(msg)}</p>` : ""}
    </div>

    <div class="grid">
      <div class="card">
        <h2>Dashboard</h2>
        <p>Bot token: <b>${esc(maskToken(config.botToken))}</b></p>
        <p>Chat ID: <b>${esc(config.chatId || "(chưa cấu hình)")}</b></p>
        <p>Check interval: <b>${config.checkIntervalMs} ms</b></p>
        <p>Send delay: <b>${config.sendDelayMs} ms</b></p>
        <p>Workers: <b>${config.apis.length}</b></p>
        <p>Worker enabled: <b>${config.workerEnabled ? "Bật" : "Tắt"}</b></p>
        <p>Total sent: <b>${totalSent}</b></p>
        <p>Total errors: <b>${totalErrors}</b></p>
        <p>Seen refs: <b>${seenList.length}</b></p>
        <p>Last check: <small>${esc(lastCheckAt || "Chưa có")}</small></p>
        <p>Last success: <small>${esc(lastSuccessAt || "Chưa có")}</small></p>
      </div>

      <div class="card">
        <h2>Sửa bot / admin</h2>
        <form method="POST" action="/settings-core">
          <label>Bot Token</label><br/><br/>
          <input type="text" name="botToken" value="${esc(config.botToken)}" placeholder="Dán bot token vào đây"/>
          <br/><br/>
          <label>Chat ID</label><br/><br/>
          <input type="text" name="chatId" value="${esc(config.chatId)}" placeholder="-100..."/>
          <br/><br/>
          <label>Mật khẩu admin</label><br/><br/>
          <input type="text" name="adminPassword" value="${esc(config.adminPassword)}"/>
          <br/><br/>
          <button type="submit">Lưu bot / admin</button>
        </form>
      </div>

      <div class="card">
        <h2>Cron / tốc độ</h2>
        <form method="POST" action="/settings-speed">
          <label>Check interval (ms)</label><br/><br/>
          <input type="number" name="checkIntervalMs" min="1000" max="3600000" value="${config.checkIntervalMs}"/>
          <br/><br/>
          <label>Send delay (ms)</label><br/><br/>
          <input type="number" name="sendDelayMs" min="0" max="60000" value="${config.sendDelayMs}"/>
          <br/><br/>
          <label>Retry Telegram</label><br/><br/>
          <input type="number" name="telegramRetry" min="1" max="20" value="${config.telegramRetry}"/>
          <br/><br/>
          <label>Retry delay (ms)</label><br/><br/>
          <input type="number" name="telegramRetryDelayMs" min="100" max="60000" value="${config.telegramRetryDelayMs}"/>
          <br/><br/>
          <label>Max seen</label><br/><br/>
          <input type="number" name="maxSeen" min="100" max="100000" value="${config.maxSeen}"/>
          <br/><br/>
          <label><input type="checkbox" name="batchMode" ${config.batchMode ? "checked" : ""}/> Batch mode</label><br/><br/>
          <label><input type="checkbox" name="workerEnabled" ${config.workerEnabled ? "checked" : ""}/> Bật worker</label><br/><br/>
          <button type="submit">Lưu tốc độ</button>
        </form>
      </div>
    </div>

    <div class="card">
      <h2>Thêm API</h2>
      <form method="POST" action="/api/add">
        <div class="grid">
          <div>
            <label>Tên API</label><br/><br/>
            <input type="text" name="name" placeholder="Ví dụ: MB API phụ"/>
          </div>
          <div>
            <label>Link API</label><br/><br/>
            <input type="text" name="url" placeholder="https://..."/>
          </div>
        </div>
        <br/>
        <button type="submit">Thêm API</button>
      </form>
    </div>

    <div class="card">
      <h2>Danh sách API</h2>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Tên</th>
            <th>URL</th>
            <th>Trạng thái</th>
            <th>Dashboard API</th>
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>${apiRowsHtml()}</tbody>
      </table>
    </div>
  `);
}

const server = http.createServer(async (req, res) => {
  try {
    const parsedUrl = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const pathname = parsedUrl.pathname;

    if (req.method === "GET" && pathname === "/health") {
      res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
      res.end(JSON.stringify({
        ok: true,
        time: nowISO(),
        lastCheckAt,
        lastSuccessAt,
        totalSent,
        totalErrors,
        intervalMs: config.checkIntervalMs,
        workers: config.apis.length,
        workerEnabled: config.workerEnabled,
        apis: config.apis.map(a => ({
          id: a.id,
          name: a.name,
          url: a.url,
          enabled: a.enabled,
          stat: getApiStat(a.id)
        }))
      }, null, 2));
      return;
    }

    if (req.method === "GET" && pathname === "/") {
      if (!isAuthed(req)) {
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(loginPage());
        return;
      }
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(dashboardPage(parsedUrl.searchParams.get("msg") || ""));
      return;
    }

    if (req.method === "POST" && pathname === "/login") {
      const form = await parseForm(req);
      if (String(form.password || "") !== config.adminPassword) {
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        res.end(loginPage("Sai mật khẩu"));
        return;
      }
      issueSession(res);
      redirect(res, "/?msg=Đăng nhập thành công");
      return;
    }

    if (req.method === "GET" && pathname === "/logout") {
      destroySession(req, res);
      redirect(res, "/");
      return;
    }

    if (!isAuthed(req)) {
      redirect(res, "/");
      return;
    }

    if (req.method === "POST" && pathname === "/settings-core") {
      const form = await parseForm(req);
      config.botToken = String(form.botToken || "").trim();
      config.chatId = String(form.chatId || "").trim();
      config.adminPassword = String(form.adminPassword || "123456").trim() || "123456";
      saveConfig();
      redirect(res, "/?msg=Đã lưu bot/admin");
      return;
    }

    if (req.method === "POST" && pathname === "/settings-speed") {
      const form = await parseForm(req);
      config.checkIntervalMs = safeNumber(form.checkIntervalMs, config.checkIntervalMs, 1000, 3600000);
      config.sendDelayMs = safeNumber(form.sendDelayMs, config.sendDelayMs, 0, 60000);
      config.telegramRetry = safeNumber(form.telegramRetry, config.telegramRetry, 1, 20);
      config.telegramRetryDelayMs = safeNumber(form.telegramRetryDelayMs, config.telegramRetryDelayMs, 100, 60000);
      config.maxSeen = safeNumber(form.maxSeen, config.maxSeen, 100, 100000);
      config.batchMode = form.batchMode === "on";
      config.workerEnabled = form.workerEnabled === "on";
      saveConfig();
      saveState();
      startWorkers();
      redirect(res, "/?msg=Đã lưu tốc độ");
      return;
    }

    if (req.method === "POST" && pathname === "/api/add") {
      const form = await parseForm(req);
      const name = String(form.name || "").trim() || `API ${config.apis.length + 1}`;
      const url = String(form.url || "").trim();
      if (!url) {
        redirect(res, "/?msg=Thiếu URL API");
        return;
      }
      config.apis.push({ id: uid("api"), name, url, enabled: true, running: false });
      firstRunPerApi[url] = false;
      saveConfig();
      saveState();
      startWorkers();
      redirect(res, "/?msg=Đã thêm API");
      return;
    }

    if (req.method === "POST" && pathname === "/api/update") {
      const form = await parseForm(req);
      const index = safeNumber(form.index, -1, -1, config.apis.length - 1);
      if (index < 0) {
        redirect(res, "/?msg=API không hợp lệ");
        return;
      }
      const oldUrl = config.apis[index].url;
      const name = String(form.name || "").trim() || `API ${index + 1}`;
      const url = String(form.url || "").trim();
      if (!url) {
        redirect(res, "/?msg=Thiếu URL API");
        return;
      }
      config.apis[index].name = name;
      config.apis[index].url = url;
      if (oldUrl !== url) {
        delete firstRunPerApi[oldUrl];
        firstRunPerApi[url] = false;
      }
      saveConfig();
      saveState();
      startWorkers();
      redirect(res, "/?msg=Đã sửa API");
      return;
    }

    if (req.method === "POST" && pathname === "/api/delete") {
      const form = await parseForm(req);
      const index = safeNumber(form.index, -1, -1, config.apis.length - 1);
      if (index < 0 || config.apis.length <= 1) {
        redirect(res, "/?msg=Không thể xoá API này");
        return;
      }
      const removed = config.apis.splice(index, 1)[0];
      if (removed?.url) delete firstRunPerApi[removed.url];
      if (removed?.id) delete apiStats[removed.id];
      saveConfig();
      saveState();
      startWorkers();
      redirect(res, "/?msg=Đã xoá API");
      return;
    }

    if (req.method === "POST" && pathname === "/api/toggle") {
      const form = await parseForm(req);
      const index = safeNumber(form.index, -1, -1, config.apis.length - 1);
      if (index < 0) {
        redirect(res, "/?msg=API không hợp lệ");
        return;
      }
      config.apis[index].enabled = !config.apis[index].enabled;
      saveConfig();
      startWorkers();
      redirect(res, "/?msg=Đã đổi trạng thái API");
      return;
    }

    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Not found");
  } catch (err) {
    totalErrors++;
    res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Server error: " + err.message);
  }
});

async function shutdown(signal) {
  try {
    console.log(`[EXIT] ${signal}`);
    stopWorkers();
    saveConfig();
    saveState();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 5000);
  } catch {
    process.exit(1);
  }
}

async function start() {
  loadConfig();
  loadState();
  server.listen(PORT, () => {
    console.log(`[HTTP] listening on port ${PORT}`);
  });
  console.log("[BOT] FULL ALL v2 started");
  console.log("[BOT] panel: /");
  await runFirstCheckAll();
  startWorkers();
}

start().catch(err => {
  console.log("[FATAL]", err.message);
  process.exit(1);
});

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("uncaughtException", err => {
  totalErrors++;
  console.log("[uncaughtException]", err.message);
});
process.on("unhandledRejection", reason => {
  totalErrors++;
  console.log("[unhandledRejection]", String(reason));
});

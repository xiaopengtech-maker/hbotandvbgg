# MB Bot FULL ALL v2

Tính năng:
- Multi API song song
- Dashboard
- Thêm / sửa / xoá / bật tắt API trên panel
- Sửa bot token / chat id / admin password ngay trên panel
- Chỉnh cron / tốc độ ngay trên panel
- Không cần sửa file để đổi bot hay API sau lần chạy đầu

## Ubuntu VPS

```bash
sudo apt update
sudo apt install -y git unzip curl
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
unzip mbbot_full_all_v2.zip
cd mbbot_full_all_v2
npm install
node index.js
```

## PM2

```bash
sudo npm install -g pm2
pm2 start index.js --name mbbot
pm2 save
pm2 startup
```

## Panel

```text
http://IP_VPS:3000/
```

Mật khẩu mặc định:
123456

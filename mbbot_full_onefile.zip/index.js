/**
 * MB BOT FULL PANEL - 1 FILE (stable)
 * Node.js 18+
 */

const fs = require("fs");
const path = require("path");
const http = require("http");
const crypto = require("crypto");
const { URL } = require("url");

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const CONFIG_FILE = path.join(ROOT, "config.json");
const STATE_FILE = path.join(ROOT, "seen.json");

const DEFAULT_CONFIG = {
  panelTitle: "MB Bot Pro Max",
  botToken: "",
  chatId: "",
  adminPassword: "280911",
  checkIntervalMs: 4000,
  sendDelayMs: 1200,
  telegramRetry: 5,
  telegramRetryDelayMs: 1500,
  batchMode: true,
  apis: [
    {
      id: "api_1",
      name: "MB API",
      url: "https://thueapibank.com/historyapimbbank/529ac6b9fec7758cff3209ebd864e180",
      enabled: true
    }
  ]
};

let config;
let seen = new Set();
let queue = Promise.resolve();
let sessions = new Map();

function loadConfig(){
  if(!fs.existsSync(CONFIG_FILE)){
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(DEFAULT_CONFIG,null,2));
  }
  config = JSON.parse(fs.readFileSync(CONFIG_FILE));
}
function saveConfig(){
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config,null,2));
}

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

async function sendTG(text){
  if(!config.botToken || !config.chatId) return;
  const res = await fetch(`https://api.telegram.org/bot${config.botToken}/sendMessage`,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({
      chat_id:config.chatId,
      text,
      parse_mode:"HTML"
    })
  });
  const data = await res.json();
  if(!data.ok) throw new Error(JSON.stringify(data));
}

async function sendQueue(text){
  queue = queue.then(async()=>{
    let retry = config.telegramRetry;
    let delay = config.telegramRetryDelayMs;
    while(retry--){
      try{
        await sendTG(text);
        break;
      }catch(e){
        await sleep(delay);
        delay*=2;
      }
    }
    await sleep(config.sendDelayMs);
  });
}

async function checkAPI(api){
  if(!api.enabled) return;
  try{
    const res = await fetch(api.url);
    const json = await res.json();
    if(!json.TranList) return;

    const newTx = json.TranList.filter(x=>!seen.has(x.refNo));

    if(newTx.length){
      newTx.forEach(x=>seen.add(x.refNo));

      if(config.batchMode){
        let msg = `<b>${newTx.length} giao dịch mới</b>\n`;
        newTx.forEach(t=>{
          msg += `\n${t.creditAmount} - ${t.description}`;
        });
        sendQueue(msg);
      }else{
        for(const t of newTx){
          sendQueue(`${t.creditAmount} - ${t.description}`);
        }
      }
    }
  }catch(e){}
}

function startWorker(){
  setInterval(()=>{
    config.apis.forEach(checkAPI);
  }, config.checkIntervalMs);
}

function parseBody(req){
  return new Promise(res=>{
    let d="";
    req.on("data",c=>d+=c);
    req.on("end",()=>res(Object.fromEntries(new URLSearchParams(d))));
  });
}

function auth(req){
  const cookie = req.headers.cookie||"";
  return cookie.includes("auth=1");
}

function setAuth(res){
  res.setHeader("Set-Cookie","auth=1; Path=/");
}

function page(){
  return `
  <h2>${config.panelTitle}</h2>
  <form method="POST" action="/save">
  Token:<br><input name="botToken" value="${config.botToken}"><br>
  Chat ID:<br><input name="chatId" value="${config.chatId}"><br>
  Password:<br><input name="adminPassword" value="${config.adminPassword}"><br>
  <button>Save</button>
  </form>
  <hr>
  <form method="POST" action="/add">
  Add API:<br>
  <input name="url">
  <button>Add</button>
  </form>
  <ul>
  ${config.apis.map((a,i)=>`
    <li>${a.url} 
    <a href="/del?id=${a.id}">X</a>
    </li>
  `).join("")}
  </ul>
  `;
}

const server = http.createServer(async (req,res)=>{
  const url = new URL(req.url,"http://x");

  if(url.pathname==="/login"){
    if(req.method==="POST"){
      const b = await parseBody(req);
      if(b.pass===config.adminPassword){
        setAuth(res);
        res.writeHead(302,{Location:"/"});
        return res.end();
      }
    }
    return res.end(`<form method="POST"><input name="pass"><button>Login</button></form>`);
  }

  if(!auth(req)){
    res.writeHead(302,{Location:"/login"});
    return res.end();
  }

  if(url.pathname==="/save"){
    const b = await parseBody(req);
    config.botToken = b.botToken;
    config.chatId = b.chatId;
    config.adminPassword = b.adminPassword;
    saveConfig();
    res.writeHead(302,{Location:"/"});
    return res.end();
  }

  if(url.pathname==="/add"){
    const b = await parseBody(req);
    config.apis.push({
      id: crypto.randomBytes(4).toString("hex"),
      url: b.url,
      enabled:true
    });
    saveConfig();
    res.writeHead(302,{Location:"/"});
    return res.end();
  }

  if(url.pathname==="/del"){
    const id = url.searchParams.get("id");
    config.apis = config.apis.filter(x=>x.id!==id);
    saveConfig();
    res.writeHead(302,{Location:"/"});
    return res.end();
  }

  res.end(page());
});

loadConfig();
server.listen(PORT,()=>console.log("RUN "+PORT));
startWorker();

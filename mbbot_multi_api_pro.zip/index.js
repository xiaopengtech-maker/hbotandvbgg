require("dotenv").config();
const fs = require("fs");
const http = require("http");

const CONFIG_FILE = "./config.json";
const STATE_FILE = "./seen.json";

let config = JSON.parse(fs.readFileSync(CONFIG_FILE));
let seen = new Set(fs.existsSync(STATE_FILE) ? JSON.parse(fs.readFileSync(STATE_FILE)) : []);
let queue = Promise.resolve();

function saveSeen() {
  fs.writeFileSync(STATE_FILE, JSON.stringify([...seen]));
}

function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

async function sendTelegram(text){
  const res = await fetch(`https://api.telegram.org/bot${config.botToken}/sendMessage`,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({
      chat_id:config.chatId,
      text,
      parse_mode:"HTML"
    })
  });
  const data = await res.json();
  if(!data.ok) throw new Error(JSON.stringify(data));
}

function enqueue(fn){
  queue = queue.then(fn).catch(()=>{});
}

async function fetchApi(api){
  const res = await fetch(api.url);
  const json = await res.json();
  return json.TranList || [];
}

function format(tx){
  return `💸 Giao dịch mới

Số tiền: ${tx.creditAmount}
Nội dung: ${tx.description}
Time: ${tx.transactionDate}
Ref: ${tx.refNo}`;
}

async function checkApi(api){
  try{
    const list = await fetchApi(api);
    const newTx = list.filter(tx=>!seen.has(tx.refNo));

    if(!newTx.length) return;

    newTx.forEach(tx=>seen.add(tx.refNo));
    saveSeen();

    for(const tx of newTx){
      enqueue(async()=>{
        await sendTelegram(format(tx));
        await sleep(config.sendDelayMs);
      });
    }

    console.log("New tx:", newTx.length);

  }catch(e){
    console.log("API error:", e.message);
  }
}

function startWorkers(){
  config.apis.forEach((api)=>{
    setInterval(()=>checkApi(api), config.checkIntervalMs);
  });
}

http.createServer((req,res)=>{
  res.end("OK");
}).listen(3000);

startWorkers();
console.log("Multi API bot started");
